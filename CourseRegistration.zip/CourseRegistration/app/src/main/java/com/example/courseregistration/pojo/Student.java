package com.example.courseregistration.pojo;

public class Student {
    public int id = 0;
    public String name;
    public String rollNumber;
    public String course;
    public Integer priority;

    public Student() {
    }

    public Student(Integer id, String name, String rollNumber, String course, Integer priority) {
        this.id = id;
        this.name = name;
        this.rollNumber = rollNumber;
        this.course = course;
        this.priority = priority;
    }
}
