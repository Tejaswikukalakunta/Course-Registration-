package com.example.courseregistration;

import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.courseregistration.db.DBHelper;
import com.example.courseregistration.pojo.Student;
import com.google.android.material.textfield.TextInputEditText;

public class CreateStudent extends AppCompatActivity {
    Spinner spinner;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_student);
        DBHelper mydb = new DBHelper(this);
        TextInputEditText a = findViewById(R.id.name);
        TextInputEditText b = findViewById(R.id.rollnumber);
        spinner = findViewById(R.id.spn_case);
        String[] course = {"Select Priority", "Graduate", "4th Year", "3th Year", "2th Year", "1th Year"};
        ArrayAdapter<String> reqAdapter = new ArrayAdapter<String>(this, R.layout.item_sppinner_lable, course);
        reqAdapter.setDropDownViewResource(R.layout.item_sppinner_lable);
        spinner.setAdapter(reqAdapter);
        Button save = findViewById(R.id.save);
        save.setOnClickListener(v -> {
            int position = spinner.getSelectedItemPosition();
            String name = a.getText().toString().trim();
            String numm = b.getText().toString().trim();
//            Log.e(">>>", ":" + a.getText().toString() + ", " + b.getText().toString() + ", position" + position);
            if (!name.equalsIgnoreCase("") && !numm.equalsIgnoreCase("") && position != 0) {
                if (id == 0) {
                    if (mydb.insertContact(name, numm, position)) {
                        Toast.makeText(this, "Student Created Success", Toast.LENGTH_SHORT).show();
                        finish();
                    } else
                        Toast.makeText(this, "Student Creation Failed", Toast.LENGTH_SHORT).show();
                } else {
                    if (mydb.updateContact(id, name, numm, position)) {
                        Toast.makeText(this, "Student Update Success", Toast.LENGTH_SHORT).show();
                        finish();
                    } else
                        Toast.makeText(this, "Student Update Failed", Toast.LENGTH_SHORT).show();
                }
            } else
                Toast.makeText(this, "Please enter Student data.", Toast.LENGTH_SHORT).show();
        });
        if (getIntent().getExtras() != null) {
            id = getIntent().getExtras().getInt("id", 0);
            if (id != 0) {
                Student student = mydb.getStudent(id);
                a.setText("" + student.name);
                b.setText("" + student.rollNumber);
            }
        }

    }
}