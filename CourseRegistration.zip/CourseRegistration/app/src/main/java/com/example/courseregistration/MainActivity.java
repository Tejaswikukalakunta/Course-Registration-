package com.example.courseregistration;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.courseregistration.db.DBHelper;
import com.example.courseregistration.pojo.Student;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DBHelper mydb;
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    FloatingActionButton flt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb = new DBHelper(this);
        recyclerView = findViewById(R.id.recycler);
        myAdapter = new MyAdapter(this, mydb);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(myAdapter);
        flt = findViewById(R.id.flt);
        flt.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateStudent.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        List<Student> students = mydb.getAllCotacts();
        Log.e("Students count", ">" + students.size());
        myAdapter.addData(students);
    }


    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
        private List<Student> mDataset = new ArrayList<>();
        String[] course = {"Select Priority", "Graduate", "4th Year", "3th Year", "2th Year", "1th Year"};
        DBHelper mydb;
        Context context;

        public MyAdapter(MainActivity mainActivity, DBHelper mydb) {
            this.mydb = mydb;
            context = mainActivity;
        }

        static class MyViewHolder extends RecyclerView.ViewHolder {
            public View rootView;
            TextView name, numm;
            ImageView edit, delete;

            public MyViewHolder(View v) {
                super(v);
                rootView = v;
                name = v.findViewById(R.id.name);
                numm = v.findViewById(R.id.numm);
                edit = v.findViewById(R.id.edit);
                delete = v.findViewById(R.id.delete);
            }
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student, parent, false);
            MyViewHolder vh = new MyViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            Student student = mDataset.get(position);
            holder.name.setText(student.name);
            holder.numm.setText(course[student.priority]);
            holder.edit.setOnClickListener(v -> {
                Intent intent = new Intent(context, CreateStudent.class);
                intent.putExtra("id", student.id);
                context.startActivity(intent);
            });
            holder.delete.setOnClickListener(v -> {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                alertDialogBuilder.setTitle("Are you sure want to delete Student?");
                alertDialogBuilder.setPositiveButton("Ok", (dialog, which) -> {
                    mydb.deleteContact(student.id);
                    reload();
                });
                alertDialogBuilder.setNegativeButton("Cancel", (dialog, which) -> {
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            });
        }

        private void reload() {
            ((MainActivity) context).loadData();
        }

        @Override
        public int getItemCount() {
            return mDataset.size();
        }

        public void addData(List<Student> dataset) {
            this.mDataset.clear();
            this.mDataset.addAll(dataset);
            notifyDataSetChanged();
        }
    }
}